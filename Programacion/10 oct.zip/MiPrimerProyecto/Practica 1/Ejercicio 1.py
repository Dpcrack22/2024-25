num1 = 20
num2 = 10
print("La suma dels dos nombres es {}".format(num1 + num2))
print("La resta dels dos nombres es {}".format(num1 - num2))
print("La divisio dels dos nombres es {}".format(num1 // num2))
print("La multiplicacio dels dos nombres es {}".format(num1*num2))