#Imput serveix per afegir informacio mediant consola
#nombre = input("Dame un nombre")
#print ("hola", nombre)
from enum import nonmember, pickle_by_enum_name

#Nombre = input("Dame algo")
#print("has metido", Nombre)
#print(type(Nombre))

#Nombre = input("Dame algo")
#Nombre = (int(Nombre))
#print("has metido", Nombre)
#print(type(Nombre))

var1=5
var2="Hola"
var3=True
var4 = 100
#Cadena = "Variable 1 = ¨{}, Variable 2 = {}, Variable 3 = {}".format(var1,var2,var3)
#print(Cadena)
#Cadena = "Variable 1 = ¨{2}, Variable 2 = {1}, Variable 3 = {0}".format(var1,var2,var3)
#print(Cadena)
Cadena = "*{0:30.2f}*".format(var4)
print(Cadena)