#Las operaciones aritmeticcas son las que te debueben un numero entero
#las operaciones logicas son las que te debuelven un bool es decir true or false sirve sobretodo para comparar cosas
print((3==3 or 5==4) and 2==2 or 3==4)