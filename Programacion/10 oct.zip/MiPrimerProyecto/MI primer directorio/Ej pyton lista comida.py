cadena = "*"*30 + "\n" + "Comida".center(30) + "\n" + "*"*30 + "\n"
cadena = cadena + "Nombre".ljust(15) + "Precio".rjust(15)  + "\n"
cadena = cadena + "Entrecot".ljust(15) + "23.35".rjust(15)  + "\n"
cadena = cadena + "Callos".ljust(15) + "15.1".rjust(15)  + "\n"
cadena = cadena + "Patatas Bravas".ljust(15) + "9.5".rjust(15)  + "\n"

print(cadena)